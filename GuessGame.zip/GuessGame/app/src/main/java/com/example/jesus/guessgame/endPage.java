package com.example.jesus.guessgame;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

import static com.example.jesus.guessgame.R.id.activity_main;
import static com.example.jesus.guessgame.R.id.highScores;
import static com.example.jesus.guessgame.R.id.nextLevel;
import static com.example.jesus.guessgame.R.id.restart;

public class endPage extends AppCompatActivity implements View.OnClickListener {

    SharedPreferences prefs;
    SharedPreferences.Editor editor;
    String dataName = "MyData";
    String intName = "MyInt";
    int currentRun;
    int highScore;


    TextView scoring;
    TextView congrats;

    Button playAgain;
    Button returnMain;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        setContentView(R.layout.activity_end_page);

        scoring = (TextView) findViewById(R.id.finalScoring);
        congrats = (TextView)findViewById(R.id.congrats);

        prefs = getSharedPreferences(dataName, levelTwo.MODE_PRIVATE);
        editor = prefs.edit();
        currentRun = prefs.getInt(intName, 0);

        highScore = prefs.getInt(intName, 0);

        congrats.setVisibility(View.INVISIBLE);
        if (currentRun > highScore)
        {
            congrats.setVisibility(View.VISIBLE);
            highScore = currentRun;
            editor.putInt(intName, highScore);
            editor.commit();

        }

            playAgain = (Button) findViewById(R.id.restart);
            returnMain = (Button) findViewById(R.id.mainMenu);

            scoring.setText("" + highScore);

            playAgain.setOnClickListener(this);
            returnMain.setOnClickListener(this);



    }

        @Override
        public void onClick(View view)
        {

            switch (view.getId()) {
                case R.id.restart:
                    Intent play;
                    play = new Intent(this, LevelOne.class);
                    currentRun = 0;
                    editor.putInt(intName, currentRun);
                    editor.commit();
                    startActivity(play);
                    break;
                case R.id.mainMenu:
                    Intent play2;
                    play2 = new Intent(this, MainActivity.class);
                    startActivity(play2);
                    break;


            }
        }
    }
