package com.example.jesus.guessgame;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

import static com.example.jesus.guessgame.R.id.eight;
import static com.example.jesus.guessgame.R.id.five;
import static com.example.jesus.guessgame.R.id.four;
import static com.example.jesus.guessgame.R.id.nextLevel;
import static com.example.jesus.guessgame.R.id.nine;
import static com.example.jesus.guessgame.R.id.three;
import static com.example.jesus.guessgame.R.id.retry;
import static com.example.jesus.guessgame.R.id.seven;
import static com.example.jesus.guessgame.R.id.six;
import static com.example.jesus.guessgame.R.id.ten;

public class levelThree extends AppCompatActivity implements View.OnClickListener {

    SharedPreferences prefs;
    SharedPreferences.Editor editor;
    String dataName = "MyData";
    String intName = "MyInt";
    int currentRun;
    int highScore;

    int scoreTotal;
    int tries;
    int testNumber;
    int currentScore;
    int scoreHolder;
    Random randInt = new Random();


    TextView scoring;
    TextView attempts;


    Button choiceOne;
    Button choiceTwo;
    Button choiceThree;
    Button choiceFour;
    Button choiceFive;
    Button choiceSix;
    Button choiceSeven;
    Button choiceEight;
    Button choiceNine;
    Button choiceTen;

    Button replay;
    Button levelUp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        setContentView(R.layout.activity_level_three);

        scoreTotal = 0;
        tries = 01;
        testNumber = randomNumber();
        testNumber++;
        currentScore = 10;



        scoring = (TextView) findViewById(R.id.score);
        attempts = (TextView) findViewById(R.id.tries);


        prefs = getSharedPreferences(dataName, levelTwo.MODE_PRIVATE);
        editor = prefs.edit();
        scoreTotal = prefs.getInt(intName, 0);
        highScore = prefs.getInt(intName, 0);

        scoreHolder = scoreTotal;

        choiceOne = (Button) findViewById(R.id.one);
        choiceTwo = (Button) findViewById(R.id.two);
        choiceThree = (Button) findViewById(R.id.three);
        choiceFour = (Button) findViewById(R.id.four);
        choiceFive = (Button) findViewById(R.id.five);
        choiceSix = (Button) findViewById(R.id.six);
        choiceSeven = (Button) findViewById(R.id.seven);
        choiceEight = (Button) findViewById(R.id.eight);
        choiceNine = (Button) findViewById(R.id.nine);
        choiceTen = (Button) findViewById(R.id.ten);


        replay = (Button) findViewById(R.id.retry);
        levelUp = (Button) findViewById(R.id.nextLevel);

        scoring.setText("" + scoreTotal);
        attempts.setText("" + tries);

        choiceOne.setOnClickListener(this);
        choiceTwo.setOnClickListener(this);
        choiceThree.setOnClickListener(this);
        choiceFour.setOnClickListener(this);
        choiceFive.setOnClickListener(this);
        choiceSix.setOnClickListener(this);
        choiceSeven.setOnClickListener(this);
        choiceEight.setOnClickListener(this);
        choiceNine.setOnClickListener(this);
        choiceTen.setOnClickListener(this);
        replay.setOnClickListener(this);
        levelUp.setOnClickListener(this);

        choiceOne.setVisibility(View.VISIBLE);
        choiceTwo.setVisibility(View.VISIBLE);
        choiceThree.setVisibility(View.VISIBLE);
        choiceFour.setVisibility(View.VISIBLE);
        choiceFive.setVisibility(View.VISIBLE);
        choiceSix.setVisibility(View.VISIBLE);
        choiceSeven.setVisibility(View.VISIBLE);
        choiceEight.setVisibility(View.VISIBLE);
        choiceNine.setVisibility(View.VISIBLE);
        choiceTen.setVisibility(View.VISIBLE);
        replay.setVisibility(View.INVISIBLE);
        levelUp.setVisibility(View.INVISIBLE);
    }

    @Override
    public void onClick(View view) {


        int answer = 0;
        switch (view.getId()) {
            case R.id.one:
                answer = Integer.parseInt("" + choiceOne.getText());

                if (answer == testNumber) {
                    scoreTotal += currentScore;
                    Toast.makeText(getApplicationContext(), "Good Job!", Toast.LENGTH_LONG).show();
                    scoring.setText("" + scoreTotal);
                    updateScore();
                    replay.setVisibility(View.VISIBLE);
                    levelUp.setVisibility(View.VISIBLE);
                } else {
                    choiceOne.setVisibility(View.INVISIBLE);
                    tries++;
                    currentScore--;
                    Toast.makeText(getApplicationContext(), "Wrong!", Toast.LENGTH_LONG).show();
                    attempts.setText("" + tries);

                }
                break;

            case R.id.two:
                answer = Integer.parseInt("" + choiceTwo.getText());

                if (answer == testNumber) {
                    scoreTotal += currentScore;
                    Toast.makeText(getApplicationContext(), "Good Job!", Toast.LENGTH_LONG).show();
                    scoring.setText("" + scoreTotal);
                    updateScore();
                    replay.setVisibility(View.VISIBLE);
                    levelUp.setVisibility(View.VISIBLE);
                } else {
                    choiceTwo.setVisibility(View.INVISIBLE);
                    tries++;
                    currentScore--;
                    Toast.makeText(getApplicationContext(), "Wrong!", Toast.LENGTH_LONG).show();
                    attempts.setText("" + tries);
                }
                break;

            case R.id.three:
                answer = Integer.parseInt("" + choiceThree.getText());

                if (answer == testNumber) {
                    scoreTotal += currentScore;
                    Toast.makeText(getApplicationContext(), "Good Job!", Toast.LENGTH_LONG).show();
                    scoring.setText("" + scoreTotal);
                    updateScore();
                    replay.setVisibility(View.VISIBLE);
                    levelUp.setVisibility(View.VISIBLE);
                } else {
                    choiceThree.setVisibility(View.INVISIBLE);
                    tries++;
                    currentScore--;
                    Toast.makeText(getApplicationContext(), "Wrong!", Toast.LENGTH_LONG).show();
                    attempts.setText("" + tries);
                }
                break;

            case R.id.four:
                answer = Integer.parseInt("" + choiceFour.getText());

                if (answer == testNumber) {
                    scoreTotal += currentScore;
                    Toast.makeText(getApplicationContext(), "Good Job!", Toast.LENGTH_LONG).show();
                    scoring.setText("" + scoreTotal);
                    updateScore();
                    replay.setVisibility(View.VISIBLE);
                    levelUp.setVisibility(View.VISIBLE);
                } else {
                    choiceFour.setVisibility(View.INVISIBLE);
                    tries++;
                    currentScore--;
                    Toast.makeText(getApplicationContext(), "Wrong!", Toast.LENGTH_LONG).show();
                    attempts.setText("" + tries);
                }
                break;

            case R.id.five:
                answer = Integer.parseInt("" + choiceFive.getText());

                if (answer == testNumber) {
                    scoreTotal += currentScore;
                    Toast.makeText(getApplicationContext(), "Good Job!", Toast.LENGTH_LONG).show();
                    scoring.setText("" + scoreTotal);
                    updateScore();
                    replay.setVisibility(View.VISIBLE);
                    levelUp.setVisibility(View.VISIBLE);

                } else {
                    choiceFive.setVisibility(View.INVISIBLE);
                    tries++;
                    currentScore--;
                    Toast.makeText(getApplicationContext(), "Wrong!", Toast.LENGTH_LONG).show();
                    attempts.setText("" + tries);
                }
                break;

            case R.id.six:
                answer = Integer.parseInt("" + choiceSix.getText());

                if (answer == testNumber) {
                    scoreTotal += currentScore;
                    Toast.makeText(getApplicationContext(), "Good Job!", Toast.LENGTH_LONG).show();
                    scoring.setText("" + scoreTotal);
                    updateScore();
                    replay.setVisibility(View.VISIBLE);
                    levelUp.setVisibility(View.VISIBLE);

                } else {
                    choiceSix.setVisibility(View.INVISIBLE);
                    tries++;
                    currentScore--;
                    Toast.makeText(getApplicationContext(), "Wrong!", Toast.LENGTH_LONG).show();
                    attempts.setText("" + tries);
                }
                break;

            case R.id.seven:
                answer = Integer.parseInt("" + choiceSeven.getText());

                if (answer == testNumber) {
                    scoreTotal += currentScore;
                    Toast.makeText(getApplicationContext(), "Good Job!", Toast.LENGTH_LONG).show();
                    scoring.setText("" + scoreTotal);
                    updateScore();
                    replay.setVisibility(View.VISIBLE);
                    levelUp.setVisibility(View.VISIBLE);
                } else {
                    choiceSeven.setVisibility(View.INVISIBLE);
                    tries++;
                    currentScore--;
                    Toast.makeText(getApplicationContext(), "Wrong!", Toast.LENGTH_LONG).show();
                    attempts.setText("" + tries);
                }
                break;

            case R.id.eight:
                answer = Integer.parseInt("" + choiceEight.getText());

                if (answer == testNumber) {
                    scoreTotal += currentScore;
                    Toast.makeText(getApplicationContext(), "Good Job!", Toast.LENGTH_LONG).show();
                    scoring.setText("" + scoreTotal);
                    updateScore();
                    replay.setVisibility(View.VISIBLE);
                    levelUp.setVisibility(View.VISIBLE);
                } else {
                    choiceEight.setVisibility(View.INVISIBLE);
                    tries++;
                    currentScore--;
                    Toast.makeText(getApplicationContext(), "Wrong!", Toast.LENGTH_LONG).show();
                    attempts.setText("" + tries);
                }
                break;

            case R.id.nine:
                answer = Integer.parseInt("" + choiceNine.getText());

                if (answer == testNumber) {
                    scoreTotal += currentScore;
                    Toast.makeText(getApplicationContext(), "Good Job!", Toast.LENGTH_LONG).show();
                    scoring.setText("" + scoreTotal);
                    updateScore();
                    replay.setVisibility(View.VISIBLE);
                    levelUp.setVisibility(View.VISIBLE);
                } else {
                    choiceNine.setVisibility(View.INVISIBLE);
                    tries++;
                    currentScore--;
                    Toast.makeText(getApplicationContext(), "Wrong!", Toast.LENGTH_LONG).show();
                    attempts.setText("" + tries);
                }
                break;

            case R.id.ten:
                answer = Integer.parseInt("" + choiceTen.getText());

                if (answer == testNumber) {
                    scoreTotal += currentScore;
                    Toast.makeText(getApplicationContext(), "Good Job!", Toast.LENGTH_LONG).show();
                    scoring.setText("" + scoreTotal);
                    updateScore();
                    replay.setVisibility(View.VISIBLE);
                    levelUp.setVisibility(View.VISIBLE);
                } else {
                    choiceTen.setVisibility(View.INVISIBLE);
                    tries++;
                    currentScore--;
                    Toast.makeText(getApplicationContext(), "Wrong!", Toast.LENGTH_LONG).show();
                    attempts.setText("" + tries);
                }
                break;

            case R.id.retry:
                playAgain();
                break;

            case R.id.nextLevel:
                Intent next;
                next = new Intent(this, endPage.class);
                startActivity(next);
                break;

        }
    }

    public void playAgain() {
        choiceOne.setVisibility(View.VISIBLE);
        choiceTwo.setVisibility(View.VISIBLE);
        choiceThree.setVisibility(View.VISIBLE);
        choiceFour.setVisibility(View.VISIBLE);
        choiceFive.setVisibility(View.VISIBLE);
        choiceSix.setVisibility(View.VISIBLE);
        choiceSeven.setVisibility(View.VISIBLE);
        choiceEight.setVisibility(View.VISIBLE);
        choiceNine.setVisibility(View.VISIBLE);
        choiceTen.setVisibility(View.VISIBLE);
        replay.setVisibility(View.INVISIBLE);
        levelUp.setVisibility(View.INVISIBLE);
        scoreTotal = scoreHolder;
        tries = 1;
        currentScore = 10;
        attempts.setText("" + tries);
        scoring.setText("" + scoreTotal);
        testNumber = randomNumber();
    }

    public int randomNumber() {
        int ranNumber;
        ranNumber = randInt.nextInt(10);
        ranNumber++;
        return ranNumber;
    }

    public void updateScore() {
        currentRun = scoreTotal;
        editor.putInt(intName, currentRun);
        editor.commit();
    }
}
