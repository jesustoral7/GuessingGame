package com.example.jesus.guessgame;

        import android.content.Intent;
        import android.content.SharedPreferences;
        import android.content.pm.ActivityInfo;
        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.Button;
        import android.widget.TextView;
        import android.widget.Toast;

        import java.util.Random;

        import static android.view.View.*;
        import static com.example.jesus.guessgame.R.id.buttonThree;
        import static com.example.jesus.guessgame.R.id.nextLevel;
        import static com.example.jesus.guessgame.R.id.retry;


public class LevelOne extends AppCompatActivity implements OnClickListener {

    //high score
    SharedPreferences prefs;
    SharedPreferences.Editor editor;
    String dataName = "MyData";
    String intName = "MyInt";
    int defaultInt = 0;
    int currentRun;
    int highScore;

    int scoreTotal;
    int tries;
    int testNumber;
    int currentScore;
    Random randInt = new Random();


    TextView scoring;
    TextView attempts;


    Button choiceOne;
    Button choiceTwo;
    Button choiceThree;
    Button replay;
    Button levelUp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        setContentView(R.layout.activity_level_one);


        scoreTotal = 0;
        tries = 1;
        testNumber = randomNumber();
        testNumber++;
        currentScore = 3;


        scoring = (TextView) findViewById(R.id.score);
        attempts = (TextView) findViewById(R.id.tries);


        prefs = getSharedPreferences(dataName, MODE_PRIVATE);
        editor = prefs.edit();
        currentRun = prefs.getInt(intName, defaultInt);
        highScore = prefs.getInt(intName, defaultInt);

        choiceOne = (Button) findViewById(R.id.buttonOne);
        choiceTwo = (Button) findViewById(R.id.buttonTwo);
        choiceThree = (Button) findViewById(buttonThree);
        replay = (Button) findViewById(retry);
        levelUp = (Button) findViewById(nextLevel);

        scoring.setText("" + scoreTotal);
        attempts.setText("" + tries);

        choiceOne.setOnClickListener(this);
        choiceTwo.setOnClickListener(this);
        choiceThree.setOnClickListener(this);
        replay.setOnClickListener(this);
        levelUp.setOnClickListener(this);

        replay.setVisibility(View.INVISIBLE);
        levelUp.setVisibility(View.INVISIBLE);

    }

    @Override
    public void onClick(View view) {


        int answer = 0;
        switch (view.getId()) {
            case R.id.buttonOne:
                answer = Integer.parseInt("" + choiceOne.getText());

                if (answer == testNumber) {
                    scoreTotal = currentScore;
                    Toast.makeText(getApplicationContext(), "Good Job!", Toast.LENGTH_LONG).show();
                    scoring.setText("" + scoreTotal);
                    updateScore();
                    replay.setVisibility(View.VISIBLE);
                    levelUp.setVisibility(View.VISIBLE);

                } else {
                    view.setVisibility(INVISIBLE);
                    tries++;
                    currentScore--;
                    Toast.makeText(getApplicationContext(), "Wrong!", Toast.LENGTH_LONG).show();
                    attempts.setText("" + tries);

                }
                break;

            case R.id.buttonTwo:
                answer = Integer.parseInt("" + choiceTwo.getText());

                if (answer == testNumber) {
                    scoreTotal = currentScore;
                    Toast.makeText(getApplicationContext(), "Good Job!", Toast.LENGTH_LONG).show();
                    scoring.setText("" + scoreTotal);
                    updateScore();
                    replay.setVisibility(View.VISIBLE);
                    levelUp.setVisibility(View.VISIBLE);
                } else {
                    view.setVisibility(INVISIBLE);
                    tries++;
                    currentScore--;
                    Toast.makeText(getApplicationContext(), "Wrong!", Toast.LENGTH_LONG).show();
                    attempts.setText("" + tries);
                }
                break;

            case buttonThree:
                answer = Integer.parseInt("" + choiceThree.getText());

                if (answer == testNumber) {
                    scoreTotal = currentScore;
                    Toast.makeText(getApplicationContext(), "Good Job!", Toast.LENGTH_LONG).show();
                    scoring.setText("" + scoreTotal);
                    updateScore();
                    replay.setVisibility(View.VISIBLE);
                    levelUp.setVisibility(View.VISIBLE);

                } else {
                    view.setVisibility(INVISIBLE);
                    tries++;
                    currentScore--;
                    Toast.makeText(getApplicationContext(), "Wrong!", Toast.LENGTH_LONG).show();
                    attempts.setText("" + tries);
                }
                break;

            case retry:
                playAgain();
                break;

            case nextLevel:
                Intent next;
                next = new Intent(this, levelTwo.class);
                startActivity(next);
                break;

        }
    }

    public void playAgain() {
        choiceOne.setVisibility(View.VISIBLE);
        choiceTwo.setVisibility(View.VISIBLE);
        choiceThree.setVisibility(View.VISIBLE);
        replay.setVisibility(View.INVISIBLE);
        levelUp.setVisibility(View.INVISIBLE);
        scoreTotal = 0;
        tries = 1;
        currentScore = 3;
        attempts.setText("" + tries);
        scoring.setText("" + scoreTotal);
        testNumber = randomNumber();
    }

    public int randomNumber() {
        int ranNumber;
        ranNumber = randInt.nextInt(3);
        ranNumber++;
        return ranNumber;
    }

    public void updateScore() {
        currentRun = scoreTotal;
        editor.putInt(intName, currentRun);
        editor.commit();
    }
}
