package com.example.jesus.guessgame;

        import android.content.Intent;
        import android.content.SharedPreferences;
        import android.content.pm.ActivityInfo;
        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.Button;
        import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    SharedPreferences prefs;
    SharedPreferences.Editor editor;
    String dataName = "MyData";
    String intName = "MyString";
    int defaultInt = 0;
    //all activities see this??
    public static int highScore;
    public static int currentRun;

    int hiScore;

    int newHighScore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        setContentView(R.layout.activity_main);



        prefs = getSharedPreferences(dataName, endPage.MODE_PRIVATE);
        editor = prefs.edit();
        newHighScore = prefs.getInt(intName, highScore);



        editor.putInt(intName, highScore);
        editor.commit();

        TextView highS = (TextView) findViewById(R.id.highScores);
        highS.setText("" + highScore);





        Button playButton = (Button)findViewById(R.id.playButton);
        playButton.setOnClickListener(this);
    }

    @Override
        public void onClick(View view) {
        Intent play;
        play = new Intent(this, LevelOne.class);
        startActivity(play);
    }
}
