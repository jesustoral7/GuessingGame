package com.example.jesus.guessgame;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

import static com.example.jesus.guessgame.R.id.highScores;
import static com.example.jesus.guessgame.R.id.nextLevel;
import static com.example.jesus.guessgame.R.id.numberFive;
import static com.example.jesus.guessgame.R.id.four;
import static com.example.jesus.guessgame.R.id.three;
import static com.example.jesus.guessgame.R.id.retry;

public class levelTwo extends AppCompatActivity implements View.OnClickListener {
    SharedPreferences prefs;
    SharedPreferences.Editor editor;
    String dataName = "MyData";
    String intName = "MyInt";

    int currentRun;
    int highScore;

    int scoreTotal;
    int tries;
    int testNumber;
    int currentScore;
    int scoreHolder;
    Random randInt = new Random();


    TextView scoring;
    TextView attempts;


    Button choiceOne;
    Button choiceTwo;
    Button choiceThree;
    Button choiceFour;
    Button choiceFive;
    Button replay;
    Button levelUp;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        setContentView(R.layout.activity_level_two);


        tries = 01;
        testNumber = randomNumber();
        testNumber++;
        currentScore = 5;


        scoring = (TextView) findViewById(R.id.score);
        attempts = (TextView) findViewById(R.id.tries);


        prefs = getSharedPreferences(dataName, LevelOne.MODE_PRIVATE);
        editor = prefs.edit();
        scoreTotal = prefs.getInt(intName, 0);
        highScore = prefs.getInt(intName, 0);
        scoreHolder = scoreTotal;

        choiceOne = (Button) findViewById(R.id.one);
        choiceTwo = (Button) findViewById(R.id.two);
        choiceThree = (Button) findViewById(three);
        choiceFour = (Button) findViewById(four);
        choiceFive = (Button) findViewById(numberFive);

        replay = (Button) findViewById(R.id.retry);
        levelUp = (Button) findViewById(R.id.nextLevel);

        scoring.setText("" + scoreTotal);
        attempts.setText("" + tries);

        choiceOne.setOnClickListener(this);
        choiceTwo.setOnClickListener(this);
        choiceThree.setOnClickListener(this);
        choiceFour.setOnClickListener(this);
        choiceFive.setOnClickListener(this);
        replay.setOnClickListener(this);
        levelUp.setOnClickListener(this);


        choiceOne.setVisibility(View.VISIBLE);
        choiceTwo.setVisibility(View.VISIBLE);
        choiceThree.setVisibility(View.VISIBLE);
        choiceFour.setVisibility(View.VISIBLE);
        choiceFive.setVisibility(View.VISIBLE);
        replay.setVisibility(View.INVISIBLE);
        levelUp.setVisibility(View.INVISIBLE);
    }

    @Override
    public void onClick(View view) {


        int answer = 0;
        switch (view.getId()) {
            case R.id.one:
                answer = Integer.parseInt("" + choiceOne.getText());

                if (answer == testNumber) {
                    scoreTotal += currentScore;
                    Toast.makeText(getApplicationContext(), "Good Job!", Toast.LENGTH_LONG).show();
                    scoring.setText("" + scoreTotal);
                    updateScore();
                    replay.setVisibility(View.VISIBLE);
                    levelUp.setVisibility(View.VISIBLE);

                } else {
                    choiceOne.setVisibility(View.INVISIBLE);
                    tries++;
                    currentScore--;
                    Toast.makeText(getApplicationContext(), "Wrong!", Toast.LENGTH_LONG).show();
                    attempts.setText("" + tries);

                }
                break;

            case R.id.two:
                answer = Integer.parseInt("" + choiceTwo.getText());

                if (answer == testNumber) {
                    scoreTotal += currentScore;
                    Toast.makeText(getApplicationContext(), "Good Job!", Toast.LENGTH_LONG).show();
                    scoring.setText("" + scoreTotal);
                    updateScore();
                    replay.setVisibility(View.VISIBLE);
                    levelUp.setVisibility(View.VISIBLE);
                } else {
                    choiceTwo.setVisibility(View.INVISIBLE);
                    tries++;
                    currentScore--;
                    Toast.makeText(getApplicationContext(), "Wrong!", Toast.LENGTH_LONG).show();
                    attempts.setText("" + tries);

                }
                break;

            case R.id.three:
                answer = Integer.parseInt("" + choiceThree.getText());

                if (answer == testNumber) {
                    scoreTotal += currentScore;
                    Toast.makeText(getApplicationContext(), "Good Job!", Toast.LENGTH_LONG).show();
                    scoring.setText("" + scoreTotal);
                    updateScore();
                    replay.setVisibility(View.VISIBLE);
                    levelUp.setVisibility(View.VISIBLE);
                } else {
                    choiceThree.setVisibility(View.INVISIBLE);
                    tries++;
                    currentScore--;
                    Toast.makeText(getApplicationContext(), "Wrong!", Toast.LENGTH_LONG).show();
                    attempts.setText("" + tries);
                }
                break;

            case R.id.four:
                answer = Integer.parseInt("" + choiceFour.getText());

                if (answer == testNumber) {
                    scoreTotal += currentScore;
                    Toast.makeText(getApplicationContext(), "Good Job!", Toast.LENGTH_LONG).show();
                    scoring.setText("" + scoreTotal);
                    updateScore();
                    replay.setVisibility(View.VISIBLE);
                    levelUp.setVisibility(View.VISIBLE);
                } else {
                    choiceFour.setVisibility(View.INVISIBLE);
                    tries++;
                    currentScore--;
                    Toast.makeText(getApplicationContext(), "Wrong!", Toast.LENGTH_LONG).show();
                    attempts.setText("" + tries);
                }
                break;

            case R.id.numberFive:
                answer = Integer.parseInt("" + choiceFive.getText());

                if (answer == testNumber) {
                    scoreTotal += currentScore;
                    Toast.makeText(getApplicationContext(), "Good Job!", Toast.LENGTH_LONG).show();
                    scoring.setText("" + scoreTotal);
                    updateScore();
                    replay.setVisibility(View.VISIBLE);
                    levelUp.setVisibility(View.VISIBLE);
                } else {
                    choiceFive.setVisibility(View.INVISIBLE);
                    tries++;
                    currentScore--;
                    Toast.makeText(getApplicationContext(), "Wrong!", Toast.LENGTH_LONG).show();
                    attempts.setText("" + tries);

                }
                break;

            case retry:
                playAgain();
                break;

            case nextLevel:
                Intent next;
                next = new Intent(this, levelThree.class);
                startActivity(next);
                break;

        }
    }

    public void playAgain() {

        choiceOne.setVisibility(View.VISIBLE);
        choiceTwo.setVisibility(View.VISIBLE);
        choiceThree.setVisibility(View.VISIBLE);
        choiceFour.setVisibility(View.VISIBLE);
        choiceFive.setVisibility(View.VISIBLE);
        replay.setVisibility(View.INVISIBLE);
        levelUp.setVisibility(View.INVISIBLE);
        scoreTotal = scoreHolder;
        tries = 1;
        currentScore = 5;
        attempts.setText("" + tries);
        scoring.setText("" + scoreTotal);
        testNumber = randomNumber();
    }

    public int randomNumber() {
        int ranNumber;
        ranNumber = randInt.nextInt(5);
        ranNumber++;
        return ranNumber;
    }

    public void updateScore() {
        currentRun = scoreTotal;
        editor.putInt(intName, currentRun);
        editor.commit();
    }
}

